import { useEffect, useMemo, useState } from 'react'
import { ArrowDownToLine, Check, Clipboard, Clock3, Download, Film, History, Link2, LoaderCircle, Menu, Settings2, ShieldCheck, Trash2, X } from 'lucide-react'

const API = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000'
type MediaInfo = { url: string; filename: string; contentType: string; size: number | null; sizeLabel: string; extension: string }
type HistoryItem = { id: string; filename: string; date: string; sizeLabel: string; url: string }
type Page = 'home' | 'downloads' | 'settings'

function formatBytes(bytes: number | null) {
  if (bytes === null) return 'Size not provided'
  const units = ['B', 'KB', 'MB', 'GB']
  let value = bytes, index = 0
  while (value >= 1024 && index < units.length - 1) { value /= 1024; index++ }
  return `${value.toFixed(index === 0 ? 0 : 1)} ${units[index]}`
}

export default function App() {
  const [page, setPage] = useState<Page>('home')
  const [url, setUrl] = useState('')
  const [info, setInfo] = useState<MediaInfo | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [progress, setProgress] = useState<number | null>(null)
  const [downloadBusy, setDownloadBusy] = useState(false)
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try { return JSON.parse(localStorage.getItem('clipvault-history') || '[]') as HistoryItem[] } catch { return [] }
  })
  const [mobileOpen, setMobileOpen] = useState(false)
  const [toast, setToast] = useState('')

  useEffect(() => { localStorage.setItem('clipvault-history', JSON.stringify(history)) }, [history])
  useEffect(() => {
    if (!toast) return
    const t = window.setTimeout(() => setToast(''), 3200)
    return () => window.clearTimeout(t)
  }, [toast])

  const nav = useMemo(() => [
    { id: 'home' as const, label: 'Downloader', icon: Download },
    { id: 'downloads' as const, label: 'My downloads', icon: History },
    { id: 'settings' as const, label: 'Settings', icon: Settings2 },
  ], [])

  async function inspectUrl() {
    setError(''); setInfo(null); setProgress(null)
    if (!url.trim()) { setError('Paste a direct media URL to get started.'); return }
    setBusy(true)
    try {
      const response = await fetch(`${API}/api/media/info`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url.trim() })
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Could not inspect this media URL.')
      setInfo(data as MediaInfo)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.')
    } finally { setBusy(false) }
  }

  async function downloadMedia() {
    if (!info) return
    setDownloadBusy(true); setProgress(0); setError('')
    try {
      const response = await fetch(`${API}/api/media/download`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: info.url, filename: info.filename })
      })
      if (!response.ok) {
        const data = await response.json().catch(() => ({}))
        throw new Error(data.error || 'Download could not be started.')
      }
      const total = Number(response.headers.get('content-length')) || info.size || 0
      const reader = response.body?.getReader()
      if (!reader) throw new Error('Your browser could not read the download stream.')
      const chunks: Uint8Array[] = []
      let received = 0
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        if (value) {
          chunks.push(value); received += value.length
          setProgress(total > 0 ? Math.min(99, Math.round(received / total * 100)) : null)
        }
      }
      const blob = new Blob(chunks, { type: info.contentType })
      const objectUrl = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = objectUrl; a.download = info.filename; document.body.appendChild(a); a.click(); a.remove()
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 30_000)
      setProgress(100)
      const item: HistoryItem = { id: crypto.randomUUID(), filename: info.filename, date: new Date().toISOString(), sizeLabel: formatBytes(received), url: info.url }
      setHistory(old => [item, ...old].slice(0, 100))
      setToast('Download received by your browser.')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Download failed.')
      setProgress(null)
    } finally { setDownloadBusy(false) }
  }

  async function pasteLink() {
    try { setUrl(await navigator.clipboard.readText()); setToast('Link pasted from clipboard.') }
    catch { setError('Clipboard access was blocked. Paste the link into the field instead.') }
  }

  function changePage(next: Page) { setPage(next); setMobileOpen(false); setError('') }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark"><Film size={21}/></div><span>clipvault</span><button className="mobile-close icon-button" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(item => <button key={item.id} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => changePage(item.id)}><item.icon size={18}/>{item.label}{item.id === 'downloads' && history.length > 0 && <span className="nav-count">{history.length}</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="privacy-card"><div className="privacy-icon"><ShieldCheck size={17}/></div><div><strong>Private workspace</strong><p>Downloads stay on your device after delivery.</p></div></div><div className="sidebar-foot">CLIPVAULT · PERSONAL EDITION</div></div>
    </aside>

    {mobileOpen && <button className="scrim" onClick={() => setMobileOpen(false)} aria-label="Close navigation"/>}
    <main className="main-area">
      <header className="topbar"><button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu/></button><div className="breadcrumb">Workspace <span>/</span> {nav.find(n => n.id === page)?.label}</div><div className="topbar-right"><span className="status-dot"/><span className="status-text">Ready</span><div className="avatar">C</div></div></header>

      {page === 'home' && <section className="content">
        <div className="hero">
          <div className="eyebrow"><span className="eyebrow-dot"/> YOUR PERSONAL MEDIA WORKSPACE</div>
          <h1>Your media.<br/><span>Your way.</span></h1>
          <p className="hero-copy">Bring an authorised media link. ClipVault will check the file and prepare it for download.</p>
          <div className="input-card">
            <div className="input-label"><Link2 size={16}/> MEDIA URL</div>
            <div className="url-row"><input value={url} onChange={e => setUrl(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') void inspectUrl() }} placeholder="Paste a direct video file URL…" aria-label="Media URL"/><button className="paste-button" onClick={() => void pasteLink()}><Clipboard size={15}/> Paste</button></div>
            <div className="input-footer"><span>Direct media links only · MP4, WebM and MOV</span><button className="primary-button" onClick={() => void inspectUrl()} disabled={busy}>{busy ? <><LoaderCircle className="spin" size={17}/> Checking…</> : <>Get media <ArrowDownToLine size={17}/></>}</button></div>
          </div>
          {error && <div className="error-banner"><X size={17}/><span>{error}</span></div>}
          {info && <div className="media-card">
            <div className="media-icon"><Film size={26}/></div><div className="media-details"><div className="media-kicker">MEDIA FILE DETECTED</div><h3>{info.filename}</h3><div className="media-meta"><span>{info.extension.toUpperCase()}</span><i/> <span>{info.contentType}</span><i/> <span>{info.sizeLabel}</span></div></div>
            <button className="download-button" onClick={() => void downloadMedia()} disabled={downloadBusy}>{downloadBusy ? <><LoaderCircle className="spin" size={17}/> Receiving…</> : <><Download size={17}/> Download file</>}</button>
            {progress !== null && <div className="progress-wrap"><div className="progress-top"><span>{progress === 100 ? 'Download received' : 'Receiving file'}</span><strong>{progress}%</strong></div><div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }}/></div></div>}
          </div>}
          {!info && !busy && <div className="feature-row"><div><ShieldCheck size={17}/><span>Permission-first downloads</span></div><div><Check size={17}/><span>No fake progress</span></div><div><Clock3 size={17}/><span>Local history</span></div></div>}
          <div className="ad-placeholder"><span className="ad-label">ADVERTISEMENT SPACE</span><span>Reserved for an approved advertising partner</span></div>
        </div>
        <div className="bottom-note"><span>ClipVault works with direct downloadable media files from approved hosts.</span><a href="#supported" onClick={e => { e.preventDefault(); setToast('Add trusted domains to MEDIA_ALLOWED_HOSTS in the backend configuration.') }}>How supported sources work</a></div>
      </section>}

      {page === 'downloads' && <section className="content page-content"><div className="page-heading"><div className="eyebrow">YOUR LIBRARY</div><h1>My downloads<span>.</span></h1><p>Your recent files delivered by ClipVault.</p></div>
        {history.length === 0 ? <div className="empty-state"><div className="empty-icon"><Download size={25}/></div><h3>No downloads yet</h3><p>Files you download will appear here.</p><button className="primary-button" onClick={() => changePage('home')}>Start downloading <ArrowDownToLine size={16}/></button></div> :
        <div className="history-list">{history.map(item => <div className="history-item" key={item.id}><div className="history-file-icon"><Film size={20}/></div><div className="history-info"><strong>{item.filename}</strong><span>{new Date(item.date).toLocaleString()} · {item.sizeLabel}</span></div><span className="completed-pill"><Check size={13}/> Received</span></div>)}</div>}
        {history.length > 0 && <button className="text-danger" onClick={() => { setHistory([]); setToast('Download history cleared.') }}><Trash2 size={15}/> Clear history</button>}
      </section>}

      {page === 'settings' && <section className="content page-content"><div className="page-heading"><div className="eyebrow">PREFERENCES</div><h1>Settings<span>.</span></h1><p>Configure your personal ClipVault workspace.</p></div>
        <div className="settings-card"><div className="setting-row"><div><strong>Download history</strong><p>History is stored locally in this browser.</p></div><span className="setting-value">Local storage</span></div><div className="setting-row"><div><strong>Supported media</strong><p>Direct MP4, WebM and MOV files from configured trusted hosts.</p></div><span className="setting-value">Direct URLs</span></div><div className="setting-row"><div><strong>Advertising</strong><p>Ad placement is reserved. AdSense is not connected or active.</p></div><span className="setting-value muted">Not configured</span></div><div className="setting-row"><div><strong>Privacy</strong><p>ClipVault does not ask for a user account in this starter.</p></div><span className="setting-value">No account</span></div></div>
      </section>}
      <footer className="footer"><span>© {new Date().getFullYear()} ClipVault</span><span>Built for personal, authorised media downloads.</span></footer>
    </main>
    {toast && <div className="toast"><Check size={16}/>{toast}</div>}
  </div>
}
