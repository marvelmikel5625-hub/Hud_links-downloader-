import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import { z } from 'zod'
import { config } from './config.js'
import { getMediaInfo, streamMedia } from './media.js'
import { safeFilename } from './security.js'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'

const app = express()
app.disable('x-powered-by')
app.use(helmet())
app.use(cors({ origin: config.clientOrigin, methods: ['GET','POST','OPTIONS'], allowedHeaders: ['Content-Type'] }))
app.use(express.json({ limit: '16kb' }))
app.use('/api', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }))

const urlSchema = z.object({ url: z.string().url().max(4096) })
const downloadSchema = urlSchema.extend({ filename: z.string().max(180).optional() })

app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'clipvault-api' }))

app.post('/api/media/info', async (req, res) => {
  const parsed = urlSchema.safeParse(req.body)
  if (!parsed.success) return res.status(400).json({ error: 'A valid URL is required.' })
  try {
    const info = await getMediaInfo(parsed.data.url)
    return res.json(info)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unable to inspect this media URL.'
    return res.status(400).json({ error: message })
  }
})

app.post('/api/media/download', async (req, res) => {
  const parsed = downloadSchema.safeParse(req.body)
  if (!parsed.success) return res.status(400).json({ error: 'A valid URL is required.' })
  let transfer: Awaited<ReturnType<typeof streamMedia>> | undefined
  try {
    transfer = await streamMedia(parsed.data.url, parsed.data.filename)
    res.status(200)
    res.setHeader('Content-Type', transfer.contentType)
    res.setHeader('Content-Disposition', `attachment; filename="${safeFilename(transfer.filename).replace(/"/g, '')}"`)
    res.setHeader('X-Content-Type-Options', 'nosniff')
    if (transfer.size !== null) res.setHeader('Content-Length', String(transfer.size))
    const source = Readable.fromWeb(transfer.body as import('node:stream/web').ReadableStream)
    req.on('close', () => { if (!res.writableEnded) transfer?.controller.abort() })
    await pipeline(source, res)
  } catch (error) {
    if (transfer) transfer.controller.abort()
    if (!res.headersSent) {
      const message = error instanceof Error ? error.message : 'Download failed.'
      res.status(400).json({ error: message })
    } else {
      res.destroy(error instanceof Error ? error : undefined)
    }
  }
})

app.use((_req, res) => res.status(404).json({ error: 'Endpoint not found.' }))
app.listen(config.port, () => {
  console.log(`ClipVault API listening on http://localhost:${config.port}`)
  if (config.allowedHosts.length === 0) console.warn('MEDIA_ALLOWED_HOSTS is empty. Configure trusted media hosts in .env.')
})
