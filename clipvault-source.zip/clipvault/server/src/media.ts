import { validateMediaUrl, safeFilename } from './security.js'
import { config } from './config.js'

const allowedTypes = new Set(['video/mp4','video/webm','video/quicktime'])
type Checked = { url: URL; response: Response; contentType: string; size: number | null; filename: string }

async function requestWithSafeRedirects(start: URL, method: 'HEAD' | 'GET'): Promise<{ response: Response; finalUrl: URL }> {
  let current = start
  for (let i = 0; i <= 3; i++) {
    await validateMediaUrl(current.toString())
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), config.timeoutMs)
    let response: Response
    try {
      response = await fetch(current, {
        method, redirect: 'manual', signal: controller.signal,
        headers: method === 'GET' ? { Range: 'bytes=0-0', 'User-Agent': 'ClipVault/1.0' } : { 'User-Agent': 'ClipVault/1.0' }
      })
    } finally { clearTimeout(timer) }
    if ([301,302,303,307,308].includes(response.status)) {
      const location = response.headers.get('location')
      if (!location || i === 3) throw new Error('The media host returned too many or invalid redirects.')
      current = new URL(location, current)
      continue
    }
    return { response, finalUrl: current }
  }
  throw new Error('Could not resolve the media URL.')
}

async function inspect(raw: string): Promise<Checked> {
  const initial = await validateMediaUrl(raw)
  let result = await requestWithSafeRedirects(initial, 'HEAD')
  if (!result.response.ok) {
    // Some hosts do not support HEAD. Retry with a one-byte range request.
    result = await requestWithSafeRedirects(initial, 'GET')
  }
  const type = (result.response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase()
  if (!allowedTypes.has(type)) {
    throw new Error(`This URL did not return a supported direct video file (received ${type || 'unknown content type'}). Use a direct MP4, WebM or MOV URL from an approved host.`)
  }
  const rawLength = result.response.headers.get('content-length')
  const size = rawLength && Number.isFinite(Number(rawLength)) ? Number(rawLength) : null
  if (size !== null && size > config.maxDownloadBytes) throw new Error('This file exceeds the configured download size limit.')
  const disposition = result.response.headers.get('content-disposition') || ''
  const match = disposition.match(/filename\*?=(?:UTF-8''|")?([^";]+)/i)
  const pathName = decodeURIComponent(result.finalUrl.pathname.split('/').pop() || '')
  const filename = safeFilename((match?.[1] || pathName || 'clipvault-video').replace(/^["']|["']$/g, ''))
  return { url: result.finalUrl, response: result.response, contentType: type, size, filename }
}

export async function getMediaInfo(raw: string) {
  const checked = await inspect(raw)
  const ext = checked.contentType === 'video/webm' ? 'webm' : checked.contentType === 'video/quicktime' ? 'mov' : 'mp4'
  const filename = checked.filename.includes('.') ? checked.filename : `${checked.filename}.${ext}`
  return {
    url: checked.url.toString(), filename, contentType: checked.contentType,
    size: checked.size, sizeLabel: checked.size === null ? 'Not provided' : formatBytes(checked.size), extension: ext
  }
}

export async function streamMedia(raw: string, requestedName?: string) {
  const checked = await inspect(raw)
  const controller = new AbortController()
  const response = await fetch(checked.url, { redirect: 'manual', signal: controller.signal, headers: { 'User-Agent': 'ClipVault/1.0' } })
  if (!response.ok || !response.body) throw new Error(`The media host could not provide the file (HTTP ${response.status}).`)
  const type = (response.headers.get('content-type') || '').split(';')[0].toLowerCase()
  if (!allowedTypes.has(type)) { controller.abort(); throw new Error('The source did not return a supported video file.') }
  const length = Number(response.headers.get('content-length'))
  if (Number.isFinite(length) && length > config.maxDownloadBytes) { controller.abort(); throw new Error('This file exceeds the configured download size limit.') }
  const ext = type === 'video/webm' ? 'webm' : type === 'video/quicktime' ? 'mov' : 'mp4'
  const fallback = checked.filename.includes('.') ? checked.filename : `${checked.filename}.${ext}`
  return { body: response.body, controller, contentType: type, filename: safeFilename(requestedName || fallback), size: Number.isFinite(length) && length > 0 ? length : null }
}
function formatBytes(n: number) {
  const units = ['B','KB','MB','GB']; let i = 0, v = n
  while (v >= 1024 && i < 3) { v /= 1024; i++ }
  return `${v.toFixed(i ? 1 : 0)} ${units[i]}`
}
