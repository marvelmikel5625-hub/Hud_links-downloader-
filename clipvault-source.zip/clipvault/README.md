# ClipVault

A private, mobile-first downloader for **direct media URLs and explicitly authorised sources**.
This is a real full-stack starter, not a universal social-platform downloader.

## What works in this version
- React + TypeScript responsive interface.
- Express + TypeScript backend.
- URL validation and configurable hostname allowlist.
- Public-DNS/IP checks and redirect revalidation.
- Direct media inspection (HEAD, with a small ranged GET fallback).
- Real server-to-browser streaming for supported direct MP4/WebM/MOV files.
- Client-side download history stored in the browser.
- Actual progress based on bytes received when the server provides a content length.
- Security headers, CORS configuration, rate limiting, request limits and safe filenames.

## Important limitations
- This version does **not** extract videos from YouTube, TikTok, Instagram, Facebook or other platforms.
- It does not remove watermarks or bypass DRM, authentication, paywalls, geo-restrictions or platform controls.
- A URL must point directly to a downloadable media file and its hostname must be in `MEDIA_ALLOWED_HOSTS`.
- Some hosts block server-side requests or do not expose content length; those sources may not work.
- AdSense is not enabled. The interface has a reserved, disabled ad slot. AdSense requires a publisher account, site review and policy compliance.

## Requirements
- Node.js 20+
- npm

## Run locally

### 1. Backend
```bash
cd server
cp .env.example .env
npm install
npm run dev
```
The API runs at `http://localhost:4000`.

Edit `MEDIA_ALLOWED_HOSTS` in `server/.env` to include trusted hosts serving your own/authorised direct media files. Example:
`MEDIA_ALLOWED_HOSTS=cdn.example.com,media.example.org`

Do not add arbitrary domains just to make every URL work.

### 2. Frontend
In another terminal:
```bash
cd client
cp .env.example .env
npm install
npm run dev
```
Open the Vite URL shown in the terminal.

## Production
- Deploy the frontend as a static Vite app (for example, Vercel).
- Deploy the backend as a Node service that supports long-lived HTTP streaming.
- Set `CLIENT_ORIGIN` to the exact deployed frontend origin.
- Set `MEDIA_ALLOWED_HOSTS` to only the domains you trust and are authorised to retrieve from.
- Set `MAX_DOWNLOAD_MB` to an appropriate resource limit.
- Use HTTPS.
- Do not deploy the backend as a short-lived serverless function for large downloads.

## Project structure
```text
clipvault/
  client/   React frontend
  server/   Express API and safe direct-media streaming
```

## Verification status
The code is provided as a runnable implementation scaffold. Run the commands above and verify it in your own environment. No claim is made that it has been runtime-tested in your hosting account.
