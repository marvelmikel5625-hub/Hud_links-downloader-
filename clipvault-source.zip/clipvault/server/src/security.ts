import { lookup } from 'node:dns/promises'
import net from 'node:net'
import { config } from './config.js'

function isPrivateIPv4(ip: string) {
  const p = ip.split('.').map(Number)
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return true
  return p[0] === 10 || p[0] === 127 || p[0] === 0 || p[0] >= 224 ||
    (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) || (p[0] === 100 && p[1] >= 64 && p[1] <= 127)
}
function isPrivateIPv6(ip: string) {
  const s = ip.toLowerCase()
  return s === '::1' || s === '::' || s.startsWith('fe80:') || s.startsWith('fc') || s.startsWith('fd') || s.startsWith('::ffff:127.') || s.startsWith('::ffff:10.')
}
export async function validateMediaUrl(raw: string): Promise<URL> {
  let url: URL
  try { url = new URL(raw) } catch { throw new Error('Enter a valid media URL.') }
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Only HTTP and HTTPS media URLs are supported.')
  if (url.username || url.password) throw new Error('URLs containing embedded credentials are not accepted.')
  if (url.port && !['80','443'].includes(url.port)) throw new Error('Custom ports are not accepted.')
  const hostname = url.hostname.toLowerCase().replace(/^\[|\]$/g, '')
  if (!hostname || hostname === 'localhost' || hostname.endsWith('.localhost') || hostname.endsWith('.local')) throw new Error('This host is not allowed.')
  if (net.isIP(hostname)) {
    const bad = net.isIPv4(hostname) ? isPrivateIPv4(hostname) : isPrivateIPv6(hostname)
    if (bad) throw new Error('Private or local network addresses are blocked.')
  } else {
    const matches = config.allowedHosts.some(h => hostname === h || hostname.endsWith(`.${h}`))
    if (!matches) throw new Error('This domain is not in your trusted media-host allowlist. Add a domain you own or are authorised to use in MEDIA_ALLOWED_HOSTS.')
    const records = await lookup(hostname, { all: true, verbatim: true })
    if (!records.length || records.some(r => net.isIPv4(r.address) ? isPrivateIPv4(r.address) : isPrivateIPv6(r.address))) {
      throw new Error('This domain resolves to a private or unsafe address and is blocked.')
    }
  }
  return url
}
export function safeFilename(input: string, fallback = 'clipvault-media') {
  const clean = input.normalize('NFKC').replace(/[\\x00-\\x1f\\x7f/\\\\:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 150)
  return clean || fallback
}
