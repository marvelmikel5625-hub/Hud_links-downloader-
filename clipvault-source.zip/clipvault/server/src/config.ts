import 'dotenv/config'

const split = (value: string | undefined) => (value || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean)

export const config = {
  port: Number(process.env.PORT || 4000),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  allowedHosts: split(process.env.MEDIA_ALLOWED_HOSTS),
  maxDownloadBytes: Math.max(1, Number(process.env.MAX_DOWNLOAD_MB || 250)) * 1024 * 1024,
  timeoutMs: Math.max(3000, Number(process.env.REQUEST_TIMEOUT_MS || 15000))
}
